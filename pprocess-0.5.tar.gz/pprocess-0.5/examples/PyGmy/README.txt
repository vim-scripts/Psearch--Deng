The PyGmy raytracer is found here:

http://www.pawfal.org/index.php?page=PyGmy

This directory contains a version modified for use with pprocess. See the
copyright and licensing information in the main README.txt file for details.

By running scene.py, scene_pmap.py or scene_queue.py (making sure that
pprocess is either installed or found by the PYTHONPATH), different
implementations can be tried - they should all produce the same image.
